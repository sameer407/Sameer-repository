package com.zkteco.user.service;

import java.util.List;

import com.zkteco.user.dto.ResultDTO;
import com.zkteco.user.entity.User;
import com.zkteco.user.error.UserNotFoundException;

//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;

public interface UserService {
	public ResultDTO saveUser(User user);

	//public List<Department> fetchDepartmentList();

	public List<User> fetchUserList();
	public List<ResultDTO> fetchUserById(String userId) throws UserNotFoundException ;
			//throws UserNotFoundException;

	
	public ResultDTO updateUser(String userId, User user);

	public User fetchUserByName(String userName);

	public ResultDTO deleteUserById(String userId);
}
