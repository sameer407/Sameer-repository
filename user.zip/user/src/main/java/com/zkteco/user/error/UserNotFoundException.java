package com.zkteco.user.error;

public class UserNotFoundException extends Exception{

	public UserNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
