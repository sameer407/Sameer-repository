package com.zkteco.user.controller;

import java.util.List;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.user.dto.ResultDTO;
import com.zkteco.user.entity.User;
import com.zkteco.user.error.UserNotFoundException;
import com.zkteco.user.service.UserService;

@RestController
@RequestMapping("api/v1/users")
public class UserController {
@Autowired
private UserService userService;

//@PostMapping("/save")
//public ResultDTO saveUser( @RequestBody User user)
//{
	//userService.saveUser(user);
	//ResultDTO result=new ResultDTO();
	//result.setCode("1234");
	//result.setMessage("saved Successfully");
	//result.setData(user);
	//return result;
//} 






@PostMapping()
public ResultDTO saveUser( @RequestBody User user)
{
	return userService.saveUser(user);
	
}   
@GetMapping("/all")
public List<User> fetchUserList()
{
	
	return userService.fetchUserList();
}

@GetMapping("users/{Id}")
public List<ResultDTO> fetchUserById(@PathVariable("Id") String userId) throws UserNotFoundException
{
	
	return userService.fetchUserById(userId);
}

@DeleteMapping("/delete/{Id}")
public ResultDTO deleteUserById(@PathVariable("Id") String userId)
{
	
	return userService.deleteUserById(userId);
}

@PutMapping("/{Id}")
public ResultDTO updateUser(@PathVariable("Id") String userId, @RequestBody User user)
{  

	return userService.updateUser(userId,user);
}

@GetMapping("/{name}")
public ResultDTO fetchUserByName(@PathVariable("name")  String userName)
{
	User user=userService.fetchUserByName(userName);
	ResultDTO result=new ResultDTO();
	result.setCode("1011");
	result.setMessage("user name fetch successfully");
	result.setData(user);
	return result;
}


}
