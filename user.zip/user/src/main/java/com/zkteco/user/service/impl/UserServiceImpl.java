package com.zkteco.user.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.user.dto.ResultDTO;
import com.zkteco.user.entity.User;
import com.zkteco.user.error.UserNotFoundException;
import com.zkteco.user.repository.UserRepository;
import com.zkteco.user.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public ResultDTO saveUser(User user) {
		// TODO Auto-generated method stub
		userRepository.save(user);

		ResultDTO result=new ResultDTO();
	result.setCode("1234");
	result.setMessage("saved Successfully");
	result.setData(user);

		return result;
	}

	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public List<ResultDTO> fetchUserById(String userId) throws UserNotFoundException{
		// TODO Auto-generated method stub
		
		List<ResultDTO> results=new ArrayList<ResultDTO>();
	
		Optional<User> user=userRepository.findById(userId);
		ResultDTO result=new ResultDTO();
		
		result.setCode("9876");
		result.setMessage("User Details");
		result.setData(user);
		results.add(result);
		if(!user.isPresent())
		{
			throw new UserNotFoundException("User not Available");
		}
		return results;
	}

@Override
	public ResultDTO deleteUserById(String userId) {
		// TODO Auto-generated method stub
		userRepository.deleteById(userId);
		ResultDTO result=new ResultDTO();
		result.setCode("1234");
		result.setMessage("Deleted Successfully");
		result.setData(userId);
		
		return result;
	}

	@Override
	public ResultDTO updateUser(String userId, User user) {
		// TODO Auto-generated method stub
	
		User useDB=userRepository.findById(userId).get();
		if(Objects.nonNull(user.getFirstName())&&!"".equals(user.getFirstName()))
		{
			useDB.setFirstName(user.getFirstName());
		}
		
		
		if(Objects.nonNull(user.getUserId())&&!"".equals(user.getUserId()))
		{
			useDB.setUserId(user.getUserId());
		}
		
		
		if(Objects.nonNull(user.getAddress())&&!"".equals(user.getAddress()))
		{
			useDB.setAddress(user.getAddress());
		}
		userRepository.save(useDB);
		
		
		ResultDTO result=new ResultDTO();
		result.setCode("2345");
		result.setMessage("successfully updated user details");
		result.setData(useDB);
		return result;
		
	}

	@Override
	public User fetchUserByName(String userName) {
		// TODO Auto-generated method stub
		return userRepository.findByFirstName(userName);
	}


}
