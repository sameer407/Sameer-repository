package com.zkteco.user.count;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class SuccessCount {
private String successCount;
private Object success;
}
