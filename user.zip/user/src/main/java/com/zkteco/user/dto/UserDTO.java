package com.zkteco.user.dto;

//import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDTO {
	private String userId;


	private String firstName;
	private String lastName;
	private String address;
	private String email_Id;
	private String userCode;
	private String gender;
	public void setCode(String string) {
		// TODO Auto-generated method stub
		System.out.println("hello nagabhishek");
	}
	public void setMessage(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setData(UserDTO userDTO) {
		// TODO Auto-generated method stub
		
	}
}
