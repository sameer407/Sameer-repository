package com.zkteco.controller.service;

import java.util.List;

//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
//import com.dailycodebuffer.Springboottutorial.error.DepartmentNotFoundException;
import com.zkteco.controller.entity.User;
import com.zkteco.error.UserNotFoundException;

//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;

public interface UserService {
	public User saveUser(User user);

	//public List<Department> fetchDepartmentList();

	public List<User> fetchUserList();
	public User fetchUserById(String userId) throws UserNotFoundException ;
			//throws UserNotFoundException;

	
	public User updateUser(String userId, User user);

	public User fetchUserByName(String userName);

	public void deleteUserById(String userId);
}
