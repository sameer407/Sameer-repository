package com.zkteco.controller.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
//import com.dailycodebuffer.Springboottutorial.error.DepartmentNotFoundException;
//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
//import com.dailycodebuffer.Springboottutorial.controller.repository.DepartmentRepository;
import com.zkteco.controller.entity.User;
import com.zkteco.controller.repository.UserRepository;
import com.zkteco.error.UserNotFoundException;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User fetchUserById(String userId) throws UserNotFoundException{
		// TODO Auto-generated method stub
		Optional<User> user=userRepository.findById(userId);
		if(!user.isPresent())
		{
			throw new UserNotFoundException("User not Available");
		}
		return user.get();
	}

@Override
	public void deleteUserById(String userId) {
		// TODO Auto-generated method stub
		userRepository.deleteById(userId);
		
	}

	@Override
	public User updateUser(String userId, User user) {
		// TODO Auto-generated method stub
		
		User useDB=userRepository.findById(userId).get();
		if(Objects.nonNull(user.getFirstName())&&!"".equals(user.getFirstName()))
		{
			useDB.setFirstName(user.getFirstName());
		}
		
		
		if(Objects.nonNull(user.getUserId())&&!"".equals(user.getUserId()))
		{
			useDB.setUserId(user.getUserId());
		}
		
		
		if(Objects.nonNull(user.getAddress())&&!"".equals(user.getAddress()))
		{
			useDB.setAddress(user.getAddress());
		}
		return userRepository.save(useDB);
		
	
	}

	@Override
	public User fetchUserByName(String userName) {
		// TODO Auto-generated method stub
		return userRepository.findByFirstName(userName);
	}


}
