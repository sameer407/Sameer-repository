package com.zkteco.controller.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResultDto {
	private String code;
	//@Value("${my.mess}")
	private String message;
	private Object data;

}
