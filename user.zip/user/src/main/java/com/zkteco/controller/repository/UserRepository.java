package com.zkteco.controller.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zkteco.controller.entity.User;

public interface UserRepository extends JpaRepository<User, String>{
	public User findByFirstName(String userName);

	
}
