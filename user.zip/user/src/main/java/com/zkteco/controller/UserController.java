package com.zkteco.controller;

import java.util.List;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.controller.entity.ResultDto;
//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
//import com.dailycodebuffer.Springboottutorial.error.DepartmentNotFoundException;
//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
//import com.dailycodebuffer.Springboottutorial.controller.entity.Department;
import com.zkteco.controller.entity.User;
//import com.dailycodebuffer.Springboottutorial.controller.service.DepartmentService;
import com.zkteco.controller.service.UserService;
import com.zkteco.error.UserNotFoundException;

@RestController
@RequestMapping("api/v1/users")
public class UserController {
@Autowired
private UserService userService;
@PostMapping("/save")
public ResultDto saveUser( @RequestBody User user)
{
	userService.saveUser(user);
	ResultDto result=new ResultDto();
	result.setCode("1234");
	result.setMessage("saved Successfully");
	result.setData(user);
	return result;
}   
@GetMapping("/all")
public List<User> fetchUserList()
{
	
	return userService.fetchUserList();
}

@GetMapping("/user/{Id}")
public ResultDto fetchUserById(@PathVariable("Id") String userId) throws UserNotFoundException
{User user=userService.fetchUserById(userId);
	ResultDto result=new ResultDto();
	result.setCode("9876");
	result.setMessage("User Details");
	result.setData(user);
	return result;
}

@DeleteMapping("/delete/{Id}")
public String deleteUserById(@PathVariable("Id") String userId)
{
	userService.deleteUserById(userId);
	return "Data Deleted Successfully";
}

@PutMapping("/users/{Id}")
public ResultDto updateUser(@PathVariable("Id") String userId, @RequestBody User user)
{   userService.updateUser(userId,user);
	ResultDto result=new ResultDto();
result.setCode("2345");
result.setMessage("successfully updated user details");
result.setData(user);
	return result;
}

@GetMapping("/users/name/{name}")
public ResultDto fetchUserByName(@PathVariable("name")  String userName)
{
	User user=userService.fetchUserByName(userName);
	ResultDto result=new ResultDto();
	result.setCode("1011");
	result.setMessage("user name fetch successfully");
	result.setData(user);
	return result;
}


}
